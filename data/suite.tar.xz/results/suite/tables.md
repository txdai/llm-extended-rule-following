# Probe-suite cross-model tables

## Behavioral scans (local greedy)

| model | mode | SCC | 95% CI | p_stable | probes |
|---|---|---|---|---|---|
| gemma-4-26b-a4b-it | nothink | 75 | [74, 75] | 0.95 | 96 |
| gemma-4-26b-a4b-it | think | 45 | [44, 51] | 1.00 | 64 |
| gpt-oss-120b | default | 102 | [102, 102] | 0.97 | 120 |
| gpt-oss-120b | final | 48 | [38, 50] | 0.60 | 64 |
| gpt-oss-20b | default | 59 | [52, 59] | 0.98 | 96 |
| gpt-oss-20b | final | 36 | [27, 37] | 0.75 | 56 |
| llama-3.3-70b-instruct | final | 32 | [31, 32] | 0.97 | 56 |
| muse-glimmer-30b | default | 54 | [53, 54] | 1.00 | 80 |
| muse-glimmer-30b | final | 54 | [53, 62] | 0.94 | 72 |
| qwen3.6-35b-a3b | nothink | 42 | [25, 50] | 0.90 | 64 |
| qwen3.6-35b-a3b | think | 44 | [32, 44] | 0.93 | 64 |

## Linear readability of the count (decode-point states, held-out ridge)

| model | site | CV R2 | CV RMSE (items) | AR rho | slope 1.0-1.2x | 1.2-1.6x |
|---|---|---|---|---|---|---|
| gemma-4-26b-a4b-it | resid_post.layer7 | 0.999 | 0.51 | 0.989 | 0.329 | 0.426 |
| gemma-4-26b-a4b-it | resid_post.layer14 | 0.999 | 0.65 | 0.987 | 0.289 | 0.245 |
| gemma-4-26b-a4b-it | resid_post.layer21 | 0.996 | 1.36 | 0.987 | 0.24 | 0.269 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 0.977 | 3.24 | 0.971 | -0.586 | -0.328 |
| gpt-oss-120b | resid_post.layer8 | 0.994 | 1.11 | 0.974 | 0.32 | 0.159 |
| gpt-oss-120b | resid_post.layer17 | 0.979 | 1.99 | 0.972 | -0.089 | 0.114 |
| gpt-oss-120b | resid_post.layer26 | 0.988 | 1.49 | 0.965 | -0.268 | 0.072 |
| gpt-oss-120b | resid_post.layer35 | 0.974 | 2.22 | 0.959 | -0.779 | -0.012 |
| gpt-oss-20b | resid_post.layer5 | 0.996 | 0.66 | 0.970 | 0.057 | 0.241 |
| gpt-oss-20b | resid_post.layer11 | 0.995 | 0.76 | 0.968 | 0.294 | -0.03 |
| gpt-oss-20b | resid_post.layer17 | 0.964 | 2.00 | 0.960 | 0.132 | -0.126 |
| gpt-oss-20b | resid_post.layer23 | 0.974 | 1.71 | 0.954 | -0.332 | -0.673 |
| llama-3.3-70b-instruct | resid_post.layer19 | 0.999 | 0.22 | 0.968 | 0.36 | 0.186 |
| llama-3.3-70b-instruct | resid_post.layer39 | 0.978 | 1.40 | 0.952 | -0.673 | -0.072 |
| llama-3.3-70b-instruct | resid_post.layer59 | 0.982 | 1.25 | 0.951 | -0.705 | -0.159 |
| llama-3.3-70b-instruct | resid_post.layer79 | 0.945 | 2.20 | 0.945 | -1.003 | -0.159 |
| muse-glimmer-30b | resid_post.layer12 | 0.999 | 0.53 | 0.980 | 0.331 | 0.12 |
| muse-glimmer-30b | resid_post.layer25 | 0.993 | 1.28 | 0.980 | 0.187 | 0.08 |
| muse-glimmer-30b | resid_post.layer38 | 0.993 | 1.32 | 0.973 | -0.516 | -0.037 |
| muse-glimmer-30b | resid_post.layer51 | 0.984 | 1.97 | 0.965 | -1.689 | -0.093 |
| qwen3.6-35b-a3b | resid_post.layer9 | 0.993 | 1.05 | 0.982 | 0.506 | 0.467 |
| qwen3.6-35b-a3b | resid_post.layer19 | 0.975 | 1.93 | 0.981 | 0.374 | 0.285 |
| qwen3.6-35b-a3b | resid_post.layer29 | 0.994 | 0.98 | 0.974 | 0.147 | 0.179 |
| qwen3.6-35b-a3b | resid_post.layer39 | 0.979 | 1.76 | 0.959 | -0.604 | -0.203 |

## Margin collapse vs behavior

| model | first negative margin | first greedy divergence | behavioral SCC |
|---|---|---|---|
| gemma-4-26b-a4b-it | 54 | 54 | 75 |
| gpt-oss-120b | 2 | 2 | 48 |
| gpt-oss-20b | 9 | 9 | 36 |
| llama-3.3-70b-instruct | 18 | 18 | 32 |
| muse-glimmer-30b | 23 | 23 | 54 |
| qwen3.6-35b-a3b | 26 | 26 | 42 |

## Interventions at the decode point

| model | site | clamp moved/exact | step moved | full: parsed / 1st-tok | linear-only: parsed / 1st-tok | residual-only: parsed / 1st-tok | random moved |
|---|---|---|---|---|---|---|---|
| gemma-4-26b-a4b-it | resid_post.layer7 | 0/0 of 49 | 0 of 9 | 0/3 of 20 | 0/3 of 20 | 0/3 of 20 | 0 of 3 |
| gemma-4-26b-a4b-it | resid_post.layer14 | 0/0 of 49 | 0 of 9 | 0/3 of 20 | 0/3 of 20 | 0/3 of 20 | 0 of 3 |
| gemma-4-26b-a4b-it | resid_post.layer21 | 0/0 of 49 | 0 of 9 | 1/4 of 20 | 0/3 of 20 | 1/4 of 20 | 1 of 3 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 0/0 of 49 | 0 of 9 | 0/20 of 20 | 0/3 of 20 | 0/20 of 20 | 1 of 3 |
| gpt-oss-120b | resid_post.layer8 | 0/1 of 62 | 0 of 9 | 0/5 of 20 | 0/4 of 20 | 0/4 of 20 | 0 of 3 |
| gpt-oss-120b | resid_post.layer17 | 0/1 of 62 | 0 of 9 | 1/7 of 20 | 0/4 of 20 | 1/5 of 20 | 0 of 3 |
| gpt-oss-120b | resid_post.layer26 | 14/1 of 62 | 0 of 9 | 18/20 of 20 | 0/4 of 20 | 14/17 of 20 | 0 of 3 |
| gpt-oss-120b | resid_post.layer35 | 9/1 of 62 | 0 of 9 | 19/20 of 20 | 0/4 of 20 | 16/18 of 20 | 0 of 3 |
| gpt-oss-20b | resid_post.layer5 | 0/1 of 46 | 0 of 9 | 0/5 of 20 | 0/5 of 20 | 0/5 of 20 | 0 of 3 |
| gpt-oss-20b | resid_post.layer11 | 0/1 of 46 | 0 of 9 | 0/5 of 20 | 0/5 of 20 | 0/5 of 20 | 0 of 3 |
| gpt-oss-20b | resid_post.layer17 | 0/1 of 46 | 0 of 9 | 2/6 of 20 | 0/5 of 20 | 2/6 of 20 | 0 of 3 |
| gpt-oss-20b | resid_post.layer23 | 0/1 of 46 | 0 of 9 | 20/20 of 20 | 0/5 of 20 | 20/20 of 20 | 0 of 3 |
| llama-3.3-70b-instruct | resid_post.layer19 | 0/1 of 41 | 0 of 9 | 0/6 of 20 | 0/6 of 20 | 0/6 of 20 | 0 of 3 |
| llama-3.3-70b-instruct | resid_post.layer39 | 0/1 of 41 | 0 of 9 | 2/7 of 20 | 0/6 of 20 | 1/6 of 20 | 0 of 3 |
| llama-3.3-70b-instruct | resid_post.layer59 | 0/1 of 41 | 0 of 9 | 6/10 of 20 | 0/6 of 20 | 5/9 of 20 | 0 of 3 |
| llama-3.3-70b-instruct | resid_post.layer79 | 0/1 of 41 | 0 of 9 | 20/20 of 20 | 0/6 of 20 | 20/20 of 20 | 0 of 3 |
| muse-glimmer-30b | resid_post.layer12 | 0/1 of 35 | 0 of 9 | 0/3 of 20 | 0/3 of 20 | 0/3 of 20 | 0 of 3 |
| muse-glimmer-30b | resid_post.layer25 | 0/1 of 35 | 0 of 9 | 0/3 of 20 | 0/3 of 20 | 0/3 of 20 | 0 of 3 |
| muse-glimmer-30b | resid_post.layer38 | 0/1 of 35 | 0 of 9 | 1/4 of 20 | 0/3 of 20 | 1/4 of 20 | 0 of 3 |
| muse-glimmer-30b | resid_post.layer51 | 0/1 of 35 | 0 of 9 | 20/20 of 20 | 0/3 of 20 | 20/20 of 20 | 0 of 3 |
| qwen3.6-35b-a3b | resid_post.layer9 | 0/1 of 54 | 0 of 9 | 0/4 of 20 | 0/4 of 20 | 0/4 of 20 | 0 of 3 |
| qwen3.6-35b-a3b | resid_post.layer19 | 0/1 of 54 | 0 of 9 | 0/4 of 20 | 0/4 of 20 | 0/4 of 20 | 0 of 3 |
| qwen3.6-35b-a3b | resid_post.layer29 | 0/1 of 54 | 0 of 9 | 0/4 of 20 | 0/4 of 20 | 0/4 of 20 | 0 of 3 |
| qwen3.6-35b-a3b | resid_post.layer39 | 0/1 of 54 | 0 of 9 | 4/20 of 20 | 0/4 of 20 | 4/20 of 20 | 0 of 3 |

## Mixed-sequence deconfound (count k among distractors, length L)

| model | behavioral acc | site | CV R2 count | CV R2 length | cos(d_count, d_len) |
|---|---|---|---|---|---|
| gemma-4-26b-a4b-it | 28.57% | resid_post.layer7 | 0.945 | 0.998 | 0.341 |
| gemma-4-26b-a4b-it | 28.57% | resid_post.layer14 | 0.878 | 0.990 | 0.283 |
| gemma-4-26b-a4b-it | 28.57% | resid_post.layer21 | 0.943 | 0.904 | 0.275 |
| gemma-4-26b-a4b-it | 28.57% | resid_post.layer29 | 0.900 | 0.372 | 0.076 |
| gpt-oss-120b | 9.52% | resid_post.layer8 | 0.981 | 1.000 | 0.061 |
| gpt-oss-120b | 9.52% | resid_post.layer17 | 0.798 | 0.989 | -0.025 |
| gpt-oss-120b | 9.52% | resid_post.layer26 | 0.863 | 0.963 | 0.031 |
| gpt-oss-120b | 9.52% | resid_post.layer35 | 0.898 | 0.937 | -0.220 |
| gpt-oss-20b | 26.19% | resid_post.layer5 | 0.975 | 1.000 | 0.056 |
| gpt-oss-20b | 26.19% | resid_post.layer11 | 0.896 | 0.996 | 0.153 |
| gpt-oss-20b | 26.19% | resid_post.layer17 | 0.698 | 0.972 | 0.423 |
| gpt-oss-20b | 26.19% | resid_post.layer23 | 0.855 | 0.914 | 0.122 |
| llama-3.3-70b-instruct | 47.62% | resid_post.layer19 | 0.985 | 1.000 | 0.034 |
| llama-3.3-70b-instruct | 47.62% | resid_post.layer39 | 0.899 | 0.937 | 0.244 |
| llama-3.3-70b-instruct | 47.62% | resid_post.layer59 | 0.945 | 0.906 | 0.244 |
| llama-3.3-70b-instruct | 47.62% | resid_post.layer79 | 0.896 | 0.840 | 0.211 |
| muse-glimmer-30b | 9.52% | resid_post.layer12 | 0.990 | 0.999 | 0.218 |
| muse-glimmer-30b | 9.52% | resid_post.layer25 | 0.848 | 0.996 | 0.082 |
| muse-glimmer-30b | 9.52% | resid_post.layer38 | 0.863 | 0.936 | 0.096 |
| muse-glimmer-30b | 9.52% | resid_post.layer51 | 0.844 | 0.972 | -0.147 |
| qwen3.6-35b-a3b | 28.57% | resid_post.layer9 | 0.847 | 0.993 | 0.059 |
| qwen3.6-35b-a3b | 28.57% | resid_post.layer19 | 0.850 | 0.905 | 0.267 |
| qwen3.6-35b-a3b | 28.57% | resid_post.layer29 | 0.921 | 0.861 | 0.262 |
| qwen3.6-35b-a3b | 28.57% | resid_post.layer39 | 0.976 | 0.795 | 0.014 |

## Subspace controls: readouts (multi-prompt cache, count-held-out folds)

| model | site | linear R2 | last digit raw acc (neighbour) | last digit resid acc (perm max) | P10 R2 resid cos/sin | periods readable | T rank | max cos(G,U) | max cos(L,U) |
|---|---|---|---|---|---|---|---|---|---|
| gemma-4-26b-a4b-it | resid_post.layer7 | 0.999 | 0.021 (0.2739) | 0.0378 (0.1553) | --/-- | [20] | 74 | 0.0564 | 0.0199 |
| gemma-4-26b-a4b-it | resid_post.layer14 | 0.998 | 0.0976 (0.68) | 0.1763 (0.1469) | --/-- | [10, 20] | 74 | 0.026 | 0.015 |
| gemma-4-26b-a4b-it | resid_post.layer21 | 0.999 | 0.8657 (0.1049) | 0.8499 (0.1658) | --/-- | [2, 5, 10, 20] | 74 | 0.0454 | 0.0082 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 0.971 | 0.7114 (0.2151) | 0.8059 (0.1427) | --/-- | [5, 10, 20] | 74 | 0.1394 | 0.0182 |
| gpt-oss-120b | resid_post.layer8 | 0.992 | 0.0377 (0.3305) | 0.0502 (0.1548) | --/-- | [] | 37 | 0.2305 | 0.1647 |
| gpt-oss-120b | resid_post.layer17 | 0.993 | 0.318 (0.431) | 0.3431 (0.1799) | --/-- | [] | 37 | 0.1884 | 0.1516 |
| gpt-oss-120b | resid_post.layer26 | 0.991 | 0.364 (0.4812) | 0.4226 (0.1757) | --/-- | [10] | 37 | 0.4164 | 0.3181 |
| gpt-oss-120b | resid_post.layer35 | 0.986 | 0.159 (0.5983) | 0.2134 (0.1464) | --/-- | [10] | 37 | 0.6243 | 0.4635 |
| gpt-oss-20b | resid_post.layer5 | 0.997 | 0.0109 (0.4511) | 0.0272 (0.1766) | --/-- | [] | 32 | 0.2209 | 0.1453 |
| gpt-oss-20b | resid_post.layer11 | 0.995 | 0.0272 (0.788) | 0.0625 (0.1821) | --/-- | [10] | 32 | 0.1944 | 0.1385 |
| gpt-oss-20b | resid_post.layer17 | 0.983 | 0.3125 (0.5625) | 0.3261 (0.1821) | --/-- | [10] | 32 | 0.2161 | 0.1561 |
| gpt-oss-20b | resid_post.layer23 | 0.971 | 0.3315 (0.5217) | 0.2989 (0.144) | --/-- | [10] | 32 | 0.5369 | 0.336 |
| llama-3.3-70b-instruct | resid_post.layer19 | 0.997 | 0.1276 (0.7908) | 0.3903 (0.1531) | --/-- | [] | 30 | 0.1678 | 0.0472 |
| llama-3.3-70b-instruct | resid_post.layer39 | 0.973 | 0.574 (0.3061) | 0.6301 (0.1607) | --/-- | [5, 10] | 30 | 0.5062 | 0.1854 |
| llama-3.3-70b-instruct | resid_post.layer59 | 0.971 | 0.4541 (0.3852) | 0.5714 (0.1633) | --/-- | [10] | 30 | 0.3939 | 0.1939 |
| llama-3.3-70b-instruct | resid_post.layer79 | 0.941 | 0.1735 (0.6658) | 0.4235 (0.1378) | --/-- | [10] | 30 | 0.6106 | 0.3048 |
| muse-glimmer-30b | resid_post.layer12 | 0.998 | 0.0406 (0.6962) | 0.0662 (0.1203) | --/-- | [20] | 53 | 0.1537 | 0.0799 |
| muse-glimmer-30b | resid_post.layer25 | 0.997 | 0.1459 (0.7233) | 0.2632 (0.1383) | --/-- | [10, 20] | 53 | 0.1448 | 0.0956 |
| muse-glimmer-30b | resid_post.layer38 | 0.993 | 0.6226 (0.3474) | 0.6226 (0.215) | --/-- | [5, 10, 20] | 53 | 0.3358 | 0.2439 |
| muse-glimmer-30b | resid_post.layer51 | 0.992 | 0.1098 (0.8135) | 0.2677 (0.1564) | --/-- | [10, 20] | 53 | 0.4714 | 0.2824 |
| qwen3.6-35b-a3b | resid_post.layer9 | 0.994 | 0.0265 (0.354) | 0.0442 (0.1363) | --/-- | [] | 41 | 0.1514 | 0.0606 |
| qwen3.6-35b-a3b | resid_post.layer19 | 0.998 | 0.0212 (0.5062) | 0.1841 (0.1115) | --/-- | [] | 41 | 0.1958 | 0.0854 |
| qwen3.6-35b-a3b | resid_post.layer29 | 0.996 | 0.5504 (0.2142) | 0.6142 (0.1593) | --/-- | [2, 10] | 41 | 0.4805 | 0.124 |
| qwen3.6-35b-a3b | resid_post.layer39 | 0.989 | 0.4319 (0.2708) | 0.5699 (0.1239) | --/-- | [2, 10] | 41 | 0.6393 | 0.1744 |

## Subspace controls: consolidation layer (full transplant at every layer)

| model | layers | first layer >= 50% | first layer >= 80% |
|---|---|---|---|
| gemma-4-26b-a4b-it | 30 | 27 | 28 |
| gpt-oss-120b | 36 | 16 | 20 |
| gpt-oss-20b | 24 | 19 | 19 |
| llama-3.3-70b-instruct | 80 | 68 | 68 |
| muse-glimmer-30b | 52 | 49 | 49 |
| qwen3.6-35b-a3b | 40 | 33 | 35 |

## Subspace controls: transplant (first-token transfer, incidental donors excluded)

| model | site | full | L | F | G | U | T d50/d90 | R d50/d90 | A d50/d90 | U_k d50/d90 | T curve |
|---|---|---|---|---|---|---|---|---|---|---|---|
| gemma-4-26b-a4b-it | resid_post.layer21 | 0.059 | 0.0 | 0.0 | 0.0 | 0.0 | 8/8 | None/None | None/None | None/None | 1:0.0 2:0.0 4:0.0 8:0.059 16:0.059 32:0.059 74:0.059 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 1.0 | 0.0 | 0.0 | 0.882 | 0.0 | 4/8 | None/None | None/None | None/None | 1:0.0 2:0.0 4:0.529 8:0.941 16:0.941 32:1.0 74:1.0 |
| gpt-oss-120b | resid_post.layer26 | 1.0 | 0.0 | 0.0 | 0.188 | 0.0 | 8/16 | 32/32 | None/None | None/None | 1:0.062 2:0.125 4:0.312 8:0.75 16:1.0 32:1.0 37:1.0 |
| gpt-oss-120b | resid_post.layer35 | 1.0 | 0.0 | 0.0 | 0.0 | 1.0 | 8/16 | 32/None | None/None | 8/None | 1:0.062 2:0.062 4:0.312 8:0.688 16:0.938 32:1.0 37:1.0 |
| gpt-oss-20b | resid_post.layer17 | 0.067 | 0.0 | 0.0 | 0.0 | 0.0 | 4/4 | 32/32 | None/None | None/None | 1:0.0 2:0.0 4:0.067 8:0.067 16:0.067 32:0.067 |
| gpt-oss-20b | resid_post.layer23 | 1.0 | 0.0 | 0.0 | 0.467 | 1.0 | 4/16 | 32/32 | None/None | 8/None | 1:0.0 2:0.2 4:0.6 8:0.6 16:1.0 32:1.0 |
| llama-3.3-70b-instruct | resid_post.layer59 | 0.286 | 0.0 | 0.0 | 0.0 | 0.0 | 8/16 | None/None | None/None | None/None | 1:0.0 2:0.0 4:0.0 8:0.143 16:0.286 30:0.286 |
| llama-3.3-70b-instruct | resid_post.layer79 | 1.0 | 0.0 | 0.0 | 0.5 | 1.0 | 16/16 | 16/None | None/None | 16/32 | 1:0.0 2:0.0 4:0.0 8:0.286 16:1.0 30:1.0 |
| muse-glimmer-30b | resid_post.layer38 | 0.059 | 0.0 | 0.0 | 0.0 | 0.0 | 8/8 | None/None | None/None | None/None | 1:0.0 2:0.0 4:0.0 8:0.059 16:0.059 32:0.059 53:0.059 |
| muse-glimmer-30b | resid_post.layer51 | 1.0 | 0.0 | 0.0 | 0.059 | 1.0 | 16/32 | 32/None | None/None | 32/32 | 1:0.0 2:0.0 4:0.0 8:0.059 16:0.824 32:1.0 53:1.0 |
| qwen3.6-35b-a3b | resid_post.layer39 | 1.0 | 0.0 | 0.0 | 0.875 | 1.0 | 2/16 | 32/32 | None/None | 8/8 | 1:0.0 2:0.562 4:0.625 8:0.812 16:1.0 32:1.0 41:1.0 |

## Subspace controls: ablation to the mean (first-token survival of the model's own answer)

| model | site | L | F | G | U | T8 | R8 | T16 | R16 | A16 |
|---|---|---|---|---|---|---|---|---|---|---|
| gemma-4-26b-a4b-it | resid_post.layer21 | 20/20 | 20/20 | 20/20 | 17/20 | 20/20 | 40/40 | 20/20 | 40/40 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 20/20 | 20/20 | 16/20 | 0/20 | 6/20 | 40/40 | 6/20 | 40/40 | 20/20 |
| gpt-oss-120b | resid_post.layer26 | 18/20 | 20/20 | 14/20 | 18/20 | 6/20 | 34/40 | 3/20 | 29/40 | 20/20 |
| gpt-oss-120b | resid_post.layer35 | 20/20 | 20/20 | 16/20 | 4/20 | 9/20 | 39/40 | 6/20 | 31/40 | 20/20 |
| gpt-oss-20b | resid_post.layer17 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 40/40 | 19/20 | 40/40 | 20/20 |
| gpt-oss-20b | resid_post.layer23 | 20/20 | 20/20 | 16/20 | 0/20 | 12/20 | 40/40 | 2/20 | 33/40 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer59 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 40/40 | 20/20 | 40/40 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer79 | 20/20 | 20/20 | 19/20 | 6/20 | 20/20 | 39/40 | 16/20 | 38/40 | 20/20 |
| muse-glimmer-30b | resid_post.layer38 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 40/40 | 20/20 | 40/40 | 20/20 |
| muse-glimmer-30b | resid_post.layer51 | 20/20 | 20/20 | 20/20 | 0/20 | 18/20 | 40/40 | 12/20 | 40/40 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer39 | 20/20 | 20/20 | 15/20 | 6/20 | 12/20 | 40/40 | 8/20 | 40/40 | 20/20 |

## Subspace controls: periodic clamps (answer moved / shift agrees with phase)

| model | site | P10 fitted pair | P10 random pair | P5 | P2 |
|---|---|---|---|---|---|
| gemma-4-26b-a4b-it | resid_post.layer21 | 0/0 of 180 | 0/0 of 180 | 0/0 of 80 | 0/0 of 20 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 0/0 of 180 | 0/0 of 180 | 0/0 of 80 | 0/0 of 20 [pair not readable] |
| gpt-oss-120b | resid_post.layer26 | 4/0 of 180 | 20/2 of 180 | 2/1 of 80 [pair not readable] | 1/1 of 20 [pair not readable] |
| gpt-oss-120b | resid_post.layer35 | 4/0 of 180 | 23/2 of 180 | 0/0 of 80 [pair not readable] | 0/0 of 20 [pair not readable] |
| gpt-oss-20b | resid_post.layer17 | 0/0 of 180 | 0/0 of 180 | 0/0 of 80 [pair not readable] | 9/7 of 20 [pair not readable] |
| gpt-oss-20b | resid_post.layer23 | 6/1 of 180 | 22/0 of 180 | 3/1 of 80 [pair not readable] | 10/8 of 20 [pair not readable] |
| llama-3.3-70b-instruct | resid_post.layer59 | 0/0 of 180 | 0/0 of 180 | -- | -- |
| llama-3.3-70b-instruct | resid_post.layer79 | 0/0 of 180 | 2/0 of 180 | -- | -- |
| muse-glimmer-30b | resid_post.layer38 | 0/0 of 180 | 0/0 of 180 | 0/0 of 80 | 0/0 of 20 [pair not readable] |
| muse-glimmer-30b | resid_post.layer51 | 0/0 of 180 | 4/0 of 180 | 0/0 of 80 [pair not readable] | 0/0 of 20 [pair not readable] |
| qwen3.6-35b-a3b | resid_post.layer39 | 0/0 of 180 | 0/0 of 180 | -- | 0/0 of 20 |

## Subspace controls: interpolation along the donor chord (informative donors only)

| model | site | n | first alpha with >= 50% donor | first alpha with >= 90% donor | intermediate answers (all alphas) | other answers |
|---|---|---|---|---|---|---|
| gemma-4-26b-a4b-it | resid_post.layer21 | 17 | -- | -- | n/a (digit tokenizer) | 0 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 17 | 0.5 | 0.6 | n/a (digit tokenizer) | 0 |
| gpt-oss-120b | resid_post.layer26 | 16 | 0.6 | 0.7 | 13 | 0 |
| gpt-oss-120b | resid_post.layer35 | 16 | 0.6 | 0.6 | 2 | 0 |
| gpt-oss-20b | resid_post.layer17 | 15 | -- | -- | 5 | 0 |
| gpt-oss-20b | resid_post.layer23 | 15 | 0.6 | 0.6 | 5 | 0 |
| llama-3.3-70b-instruct | resid_post.layer59 | 14 | -- | -- | 0 | 0 |
| llama-3.3-70b-instruct | resid_post.layer79 | 14 | 0.5 | 0.6 | 0 | 0 |
| muse-glimmer-30b | resid_post.layer38 | 17 | -- | -- | 0 | 0 |
| muse-glimmer-30b | resid_post.layer51 | 17 | 0.6 | 0.6 | 0 | 0 |
| qwen3.6-35b-a3b | resid_post.layer39 | 16 | 0.6 | 0.7 | n/a (digit tokenizer) | 0 |
