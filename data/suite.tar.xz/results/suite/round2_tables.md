# Round-2 mechanistic controls: cross-model tables

## E4. Multi-position shift of the running count: slope of answer shift vs delta

| model | site | band | S local (CI) | S local: +delta / -delta (through origin) | S local by length L | S mean (CI) | random local | random mean | decode-point local | decode-point mean | moved S local | broken |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| gpt-oss-20b | resid_post.layer5 | stable | -0.016 [-0.037, 0.007] | 0.038 / -0.071 | 13:0.0 18:-0.055 25:0.0 32:-0.01 | 0.016 [0.001, 0.03] | 0.014 [-0.003, 0.031] | 0.004 [-0.012, 0.022] | 0.003 [0.0, 0.011] | 0.015 [-0.006, 0.042] | 25/96 | 0 |
| gpt-oss-20b | resid_post.layer5 | beyond | 0.021 [0.0, 0.063] | 0.0 / 0.042 | 36:0.0 40:0.063 45:0.0 | 0.0 [-0.063, 0.058] | 0.021 [0.0, 0.063] | -0.031 [-0.111, 0.035] | 0.0 [0.0, 0.0] | 0.063 [0.0, 0.167] | 1/72 | 0 |
| gpt-oss-20b | resid_post.layer11 | stable | 0.429 [0.319, 0.534] | 0.641 / 0.217 | 13:0.565 18:0.533 25:0.243 32:0.375 | 0.034 [0.018, 0.051] | -0.075 [-0.158, -0.003] | -0.004 [-0.016, 0.005] | -0.01 [-0.045, 0.024] | -0.012 [-0.032, 0.0] | 61/96 | 0 |
| gpt-oss-20b | resid_post.layer11 | beyond | 0.076 [0.033, 0.128] | 0.0 / 0.152 | 36:0.094 40:0.133 45:0.0 | -0.094 [-0.175, -0.023] | -0.125 [-0.22, -0.035] | -0.105 [-0.183, -0.031] | -0.055 [-0.164, 0.058] | 0.0 [0.0, 0.0] | 11/72 | 0 |
| gpt-oss-20b | resid_post.layer17 | stable | 0.344 [0.243, 0.454] | 0.655 / 0.033 | 13:0.524 18:0.508 25:0.265 32:0.08 | 0.034 [0.014, 0.053] | 0.2 [0.028, 0.388] | -0.01 [-0.02, -0.002] | 0.119 [0.021, 0.211] | -0.018 [-0.041, 0.0] | 49/96 | 0 |
| gpt-oss-20b | resid_post.layer17 | beyond | -0.018 [-0.075, 0.014] | -0.052 / 0.016 | 36:0.0 40:-0.055 45:0.0 | -0.094 [-0.175, -0.023] | 0.022 [0.002, 0.05] | 0.0 [0.0, 0.0] | 0.031 [-0.166, 0.247] | 0.0 [0.0, 0.0] | 6/72 | 0 |
| gpt-oss-20b | resid_post.layer23 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 13:0.0 18:0.0 25:0.0 32:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.006 [0.0, 0.023] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| gpt-oss-20b | resid_post.layer23 | beyond | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 36:0.0 40:0.0 45:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/72 | 0 |
| gpt-oss-120b | resid_post.layer8 | stable | 0.039 [0.007, 0.084] | 0.0 / 0.078 | 17:0.157 24:0.0 34:0.0 43:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | -0.024 [-0.074, -0.0] | 3/96 | 0 |
| gpt-oss-120b | resid_post.layer8 | beyond | -0.005 [-0.028, 0.016] | -0.048 / 0.038 | 48:0.0 53:-0.016 60:0.0 | -0.001 [-0.026, 0.022] | 0.013 [-0.011, 0.033] | 0.018 [-0.002, 0.038] | -0.004 [-0.031, 0.034] | 0.024 [-0.01, 0.059] | 21/72 | 0 |
| gpt-oss-120b | resid_post.layer17 | stable | 0.197 [0.126, 0.284] | 0.168 / 0.226 | 17:0.365 24:0.376 34:0.0 43:0.047 | 0.0 [0.0, 0.0] | 0.001 [-0.064, 0.086] | 0.0 [0.0, 0.0] | 0.0 [-0.07, 0.063] | 0.0 [0.0, 0.0] | 32/96 | 0 |
| gpt-oss-120b | resid_post.layer17 | beyond | 0.088 [0.042, 0.136] | -0.018 / 0.193 | 48:0.071 53:0.035 60:0.157 | 0.035 [0.008, 0.061] | -0.175 [-0.281, -0.098] | -0.051 [-0.069, -0.035] | 0.0 [-0.087, 0.077] | 0.031 [-0.028, 0.089] | 32/72 | 0 |
| gpt-oss-120b | resid_post.layer26 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 17:0.0 24:0.0 34:0.0 43:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| gpt-oss-120b | resid_post.layer26 | beyond | -0.0 [-0.027, 0.025] | -0.059 / 0.059 | 48:0.0 53:-0.0 60:0.0 | -0.0 [-0.027, 0.025] | -0.023 [-0.044, -0.003] | -0.0 [-0.027, 0.025] | -0.025 [-0.064, 0.022] | 0.024 [-0.01, 0.059] | 24/72 | 0 |
| gpt-oss-120b | resid_post.layer35 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 17:0.0 24:0.0 34:0.0 43:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| gpt-oss-120b | resid_post.layer35 | beyond | -0.0 [-0.027, 0.025] | -0.059 / 0.059 | 48:0.0 53:-0.0 60:0.0 | -0.0 [-0.027, 0.025] | -0.0 [-0.027, 0.025] | -0.0 [-0.027, 0.025] | -0.0 [-0.04, 0.044] | 0.0 [-0.039, 0.045] | 24/72 | 0 |
| gemma-4-26b-a4b-it | resid_post.layer7 | stable | 0.004 [0.0, 0.012] | 0.0 / 0.008 | 26:0.0 38:0.016 52:0.0 68:0.0 | 0.008 [0.0, 0.02] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 1/96 | 0 |
| gemma-4-26b-a4b-it | resid_post.layer7 | beyond | -0.002 [-0.029, 0.02] | -0.043 / 0.039 | 75:0.0 82:-0.006 94:0.0 | -0.065 [-0.111, -0.025] | -0.009 [-0.037, 0.017] | -0.037 [-0.068, -0.009] | -0.02 [-0.05, 0.0] | -0.024 [-0.063, -0.003] | 20/72 | 0 |
| gemma-4-26b-a4b-it | resid_post.layer14 | stable | 0.52 [0.332, 0.739] | 0.392 / 0.647 | 26:0.065 38:0.612 52:0.504 68:0.898 | 0.012 [0.0, 0.026] | -0.24 [-0.4, -0.112] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 78/96 | 0 |
| gemma-4-26b-a4b-it | resid_post.layer14 | beyond | 0.06 [-0.162, 0.275] | -0.085 / 0.205 | 75:0.216 82:0.082 94:-0.118 | 0.059 [-0.096, 0.233] | 0.594 [0.377, 0.861] | 0.222 [0.142, 0.339] | 0.004 [-0.036, 0.039] | -0.02 [-0.05, 0.014] | 58/72 | 0 |
| gemma-4-26b-a4b-it | resid_post.layer21 | stable | 0.003 [0.0, 0.007] | 0.0 / 0.006 | 26:0.0 38:0.0 52:0.012 68:0.0 | 0.0 [0.0, 0.0] | -0.022 [-0.036, -0.009] | -0.012 [-0.026, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 3/96 | 0 |
| gemma-4-26b-a4b-it | resid_post.layer21 | beyond | 0.051 [-0.02, 0.112] | -0.064 / 0.166 | 75:-0.031 82:0.035 94:0.149 | -0.093 [-0.122, -0.065] | -0.486 [-0.75, -0.255] | 0.129 [0.085, 0.176] | -0.016 [-0.051, 0.02] | -0.002 [-0.011, 0.002] | 45/72 | 0 |
| gemma-4-26b-a4b-it | resid_post.layer29 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 26:0.0 38:0.0 52:0.0 68:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| gemma-4-26b-a4b-it | resid_post.layer29 | beyond | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 75:0.0 82:0.0 94:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/72 | 0 |
| muse-glimmer-30b | resid_post.layer12 | stable | 0.075 [0.023, 0.136] | 0.033 / 0.117 | 19:0.047 27:0.165 38:0.008 49:0.08 | 0.012 [0.003, 0.026] | -0.005 [-0.011, -0.001] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 24/96 | 0 |
| muse-glimmer-30b | resid_post.layer12 | beyond | 0.102 [0.011, 0.195] | -0.067 / 0.271 | 54:0.0 59:0.251 68:0.055 | -0.02 [-0.039, -0.006] | 0.071 [0.028, 0.128] | 0.039 [0.014, 0.074] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 25/72 | 0 |
| muse-glimmer-30b | resid_post.layer25 | stable | 0.038 [0.021, 0.059] | 0.035 / 0.04 | 19:0.0 27:0.082 38:0.016 49:0.053 | 0.01 [0.0, 0.022] | 0.02 [0.007, 0.038] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 22/96 | 0 |
| muse-glimmer-30b | resid_post.layer25 | beyond | 0.103 [0.039, 0.173] | 0.016 / 0.191 | 54:0.0 59:0.341 68:-0.031 | 0.026 [0.011, 0.044] | -0.091 [-0.177, -0.007] | -0.04 [-0.06, -0.022] | 0.016 [0.0, 0.042] | 0.0 [0.0, 0.0] | 16/72 | 0 |
| muse-glimmer-30b | resid_post.layer38 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 19:0.0 27:0.0 38:0.0 49:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| muse-glimmer-30b | resid_post.layer38 | beyond | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 54:0.0 59:0.0 68:0.0 | 0.0 [0.0, 0.0] | -0.02 [-0.037, -0.006] | 0.0 [0.0, 0.0] | 0.02 [0.0, 0.05] | 0.008 [0.0, 0.027] | 0/72 | 0 |
| muse-glimmer-30b | resid_post.layer51 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 19:0.0 27:0.0 38:0.0 49:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| muse-glimmer-30b | resid_post.layer51 | beyond | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 54:0.0 59:0.0 68:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.016 [0.0, 0.042] | 0.016 [0.0, 0.042] | 0/72 | 0 |
| qwen3.6-35b-a3b | resid_post.layer9 | stable | 0.004 [-0.011, 0.019] | -0.022 / 0.029 | 15:0.0 21:0.0 29:0.0 38:0.016 | -0.018 [-0.032, -0.005] | 0.03 [0.011, 0.051] | 0.014 [0.004, 0.028] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 12/96 | 0 |
| qwen3.6-35b-a3b | resid_post.layer9 | beyond | -0.015 [-0.046, 0.014] | -0.067 / 0.037 | 42:-0.022 46:-0.024 52:0.0 | 0.02 [0.005, 0.037] | 0.009 [0.0, 0.023] | 0.005 [0.0, 0.017] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 23/72 | 0 |
| qwen3.6-35b-a3b | resid_post.layer19 | stable | 0.024 [-0.0, 0.055] | -0.044 / 0.092 | 15:0.137 21:0.0 29:0.0 38:-0.041 | 0.0 [0.0, 0.0] | 0.016 [-0.01, 0.041] | -0.008 [-0.023, 0.006] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 31/96 | 0 |
| qwen3.6-35b-a3b | resid_post.layer19 | beyond | -0.007 [-0.025, 0.012] | -0.035 / 0.022 | 42:-0.02 46:0.0 52:0.0 | 0.0 [0.0, 0.0] | -0.044 [-0.072, -0.016] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 14/72 | 0 |
| qwen3.6-35b-a3b | resid_post.layer29 | stable | 0.013 [0.004, 0.027] | 0.0 / 0.026 | 15:0.047 21:0.0 29:0.0 38:0.006 | 0.0 [0.0, 0.0] | -0.021 [-0.066, 0.016] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 6/96 | 0 |
| qwen3.6-35b-a3b | resid_post.layer29 | beyond | 0.028 [0.011, 0.046] | -0.003 / 0.059 | 42:0.084 46:0.0 52:0.0 | 0.016 [0.0, 0.032] | -0.176 [-0.27, -0.099] | 0.0 [0.0, 0.0] | 0.016 [0.0, 0.047] | 0.0 [0.0, 0.0] | 14/72 | 0 |
| qwen3.6-35b-a3b | resid_post.layer39 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 15:0.0 21:0.0 29:0.0 38:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| qwen3.6-35b-a3b | resid_post.layer39 | beyond | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 42:0.0 46:0.0 52:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/72 | 0 |
| llama-3.3-70b-instruct | resid_post.layer19 | stable | 0.052 [0.012, 0.097] | 0.088 / 0.017 | 11:0.227 16:0.029 22:0.0 29:-0.047 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 31/96 | 0 |
| llama-3.3-70b-instruct | resid_post.layer19 | beyond | 0.004 [0.0, 0.01] | 0.008 / 0.0 | 32:0.0 35:0.0 40:0.012 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 3/72 | 0 |
| llama-3.3-70b-instruct | resid_post.layer39 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 11:0.0 16:0.0 22:0.0 29:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| llama-3.3-70b-instruct | resid_post.layer39 | beyond | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 32:0.0 35:0.0 40:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/72 | 0 |
| llama-3.3-70b-instruct | resid_post.layer59 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 11:0.0 16:0.0 22:0.0 29:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| llama-3.3-70b-instruct | resid_post.layer59 | beyond | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 32:0.0 35:0.0 40:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/72 | 0 |
| llama-3.3-70b-instruct | resid_post.layer79 | stable | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 11:0.0 16:0.0 22:0.0 29:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/96 | 0 |
| llama-3.3-70b-instruct | resid_post.layer79 | beyond | 0.0 [0.0, 0.0] | 0.0 / 0.0 | 32:0.0 35:0.0 40:0.0 | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 0/72 | 0 |

## E4. Running-count readout at item positions and the subspace S_k

| model | site | k | LOO R2 | LOO RMSE (items) | S_k explained | mean-step norm / state norm |
|---|---|---|---|---|---|---|
| gpt-oss-20b | resid_post.layer5 | 16 | 0.9645 | 1.994 | 0.9985 | 0.024 |
| gpt-oss-20b | resid_post.layer11 | 16 | 0.9573 | 2.187 | 0.96 | 0.0298 |
| gpt-oss-20b | resid_post.layer17 | 16 | 0.9664 | 1.94 | 0.9326 | 0.0221 |
| gpt-oss-20b | resid_post.layer23 | 16 | 0.9491 | 2.387 | 0.9245 | 0.0144 |
| gpt-oss-120b | resid_post.layer8 | 16 | 0.9886 | 1.469 | 0.998 | 0.021 |
| gpt-oss-120b | resid_post.layer17 | 16 | 0.9222 | 3.837 | 0.9165 | 0.0218 |
| gpt-oss-120b | resid_post.layer26 | 16 | 0.9693 | 2.411 | 0.9171 | 0.0195 |
| gpt-oss-120b | resid_post.layer35 | 16 | 0.9562 | 2.879 | 0.9589 | 0.013 |
| gemma-4-26b-a4b-it | resid_post.layer7 | 8 | 0.982 | 2.891 | 0.9873 | 0.0139 |
| gemma-4-26b-a4b-it | resid_post.layer14 | 8 | 0.9932 | 1.78 | 0.7273 | 0.0114 |
| gemma-4-26b-a4b-it | resid_post.layer21 | 8 | 0.9899 | 2.165 | 0.6368 | 0.0101 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 8 | 0.9725 | 3.573 | 0.8721 | 0.0083 |
| muse-glimmer-30b | resid_post.layer12 | 32 | 0.9577 | 3.204 | 0.9991 | 0.0202 |
| muse-glimmer-30b | resid_post.layer25 | 32 | 0.9299 | 4.125 | 0.9599 | 0.0174 |
| muse-glimmer-30b | resid_post.layer38 | 32 | 0.9413 | 3.775 | 0.9659 | 0.0205 |
| muse-glimmer-30b | resid_post.layer51 | 32 | 0.9508 | 3.455 | 0.983 | 0.014 |
| qwen3.6-35b-a3b | resid_post.layer9 | 16 | 0.9192 | 3.451 | 0.9653 | 0.0217 |
| qwen3.6-35b-a3b | resid_post.layer19 | 16 | 0.9205 | 3.423 | 0.8997 | 0.0237 |
| qwen3.6-35b-a3b | resid_post.layer29 | 16 | 0.9313 | 3.183 | 0.8591 | 0.0233 |
| qwen3.6-35b-a3b | resid_post.layer39 | 16 | 0.9759 | 1.885 | 0.9168 | 0.0203 |
| llama-3.3-70b-instruct | resid_post.layer19 | 16 | 0.9702 | 1.618 | 0.9525 | 0.0364 |
| llama-3.3-70b-instruct | resid_post.layer39 | 16 | 0.9628 | 1.808 | 0.9278 | 0.0376 |
| llama-3.3-70b-instruct | resid_post.layer59 | 16 | 0.9613 | 1.846 | 0.9268 | 0.0383 |
| llama-3.3-70b-instruct | resid_post.layer79 | 16 | 0.9644 | 1.769 | 0.948 | 0.0347 |

## E4. Rescaling the accumulation beyond CC (answer under compression of the running count)

| model | site | L | target | unedited answer | edited answer |
|---|---|---|---|---|---|
| gpt-oss-20b | resid_post.layer5 | 40 | 29 | 42 | 38 |
| gpt-oss-20b | resid_post.layer5 | 40 | 36 | 42 | 42 |
| gpt-oss-20b | resid_post.layer5 | 45 | 29 | 42 | 42 |
| gpt-oss-20b | resid_post.layer5 | 45 | 36 | 42 | 42 |
| gpt-oss-20b | resid_post.layer11 | 40 | 29 | 42 | 38 |
| gpt-oss-20b | resid_post.layer11 | 40 | 36 | 42 | 38 |
| gpt-oss-20b | resid_post.layer11 | 45 | 29 | 42 | 42 |
| gpt-oss-20b | resid_post.layer11 | 45 | 36 | 42 | 42 |
| gpt-oss-20b | resid_post.layer17 | 40 | 29 | 42 | 42 |
| gpt-oss-20b | resid_post.layer17 | 40 | 36 | 42 | 42 |
| gpt-oss-20b | resid_post.layer17 | 45 | 29 | 42 | 42 |
| gpt-oss-20b | resid_post.layer17 | 45 | 36 | 42 | 42 |
| gpt-oss-20b | resid_post.layer23 | 40 | 29 | 42 | 42 |
| gpt-oss-20b | resid_post.layer23 | 40 | 36 | 42 | 42 |
| gpt-oss-20b | resid_post.layer23 | 45 | 29 | 42 | 42 |
| gpt-oss-20b | resid_post.layer23 | 45 | 36 | 42 | 42 |
| gpt-oss-120b | resid_post.layer8 | 53 | 38 | 48 | 47 |
| gpt-oss-120b | resid_post.layer8 | 53 | 48 | 48 | 47 |
| gpt-oss-120b | resid_post.layer8 | 60 | 38 | 62 | 62 |
| gpt-oss-120b | resid_post.layer8 | 60 | 48 | 62 | 62 |
| gpt-oss-120b | resid_post.layer17 | 53 | 38 | 48 | 48 |
| gpt-oss-120b | resid_post.layer17 | 53 | 48 | 48 | 48 |
| gpt-oss-120b | resid_post.layer17 | 60 | 38 | 62 | 62 |
| gpt-oss-120b | resid_post.layer17 | 60 | 48 | 62 | 62 |
| gpt-oss-120b | resid_post.layer26 | 53 | 38 | 48 | 47 |
| gpt-oss-120b | resid_post.layer26 | 53 | 48 | 48 | 47 |
| gpt-oss-120b | resid_post.layer26 | 60 | 38 | 62 | 62 |
| gpt-oss-120b | resid_post.layer26 | 60 | 48 | 62 | 62 |
| gpt-oss-120b | resid_post.layer35 | 53 | 38 | 48 | 47 |
| gpt-oss-120b | resid_post.layer35 | 53 | 48 | 48 | 47 |
| gpt-oss-120b | resid_post.layer35 | 60 | 38 | 62 | 62 |
| gpt-oss-120b | resid_post.layer35 | 60 | 48 | 62 | 62 |
| gemma-4-26b-a4b-it | resid_post.layer7 | 82 | 60 | 82 | 81 |
| gemma-4-26b-a4b-it | resid_post.layer7 | 82 | 75 | 82 | 81 |
| gemma-4-26b-a4b-it | resid_post.layer7 | 94 | 60 | 87 | 87 |
| gemma-4-26b-a4b-it | resid_post.layer7 | 94 | 75 | 87 | 87 |
| gemma-4-26b-a4b-it | resid_post.layer14 | 82 | 60 | 82 | 100 |
| gemma-4-26b-a4b-it | resid_post.layer14 | 82 | 75 | 82 | 75 |
| gemma-4-26b-a4b-it | resid_post.layer14 | 94 | 60 | 87 | 100 |
| gemma-4-26b-a4b-it | resid_post.layer14 | 94 | 75 | 87 | 85 |
| gemma-4-26b-a4b-it | resid_post.layer21 | 82 | 60 | 82 | 71 |
| gemma-4-26b-a4b-it | resid_post.layer21 | 82 | 75 | 82 | 75 |
| gemma-4-26b-a4b-it | resid_post.layer21 | 94 | 60 | 87 | 85 |
| gemma-4-26b-a4b-it | resid_post.layer21 | 94 | 75 | 87 | 85 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 82 | 60 | 82 | 82 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 82 | 75 | 82 | 82 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 94 | 60 | 87 | 87 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 94 | 75 | 87 | 87 |
| muse-glimmer-30b | resid_post.layer12 | 59 | 43 | 59 | 55 |
| muse-glimmer-30b | resid_post.layer12 | 59 | 54 | 59 | 56 |
| muse-glimmer-30b | resid_post.layer12 | 68 | 43 | 64 | 64 |
| muse-glimmer-30b | resid_post.layer12 | 68 | 54 | 64 | 62 |
| muse-glimmer-30b | resid_post.layer25 | 59 | 43 | 59 | 55 |
| muse-glimmer-30b | resid_post.layer25 | 59 | 54 | 59 | 60 |
| muse-glimmer-30b | resid_post.layer25 | 68 | 43 | 64 | 64 |
| muse-glimmer-30b | resid_post.layer25 | 68 | 54 | 64 | 62 |
| muse-glimmer-30b | resid_post.layer38 | 59 | 43 | 59 | 59 |
| muse-glimmer-30b | resid_post.layer38 | 59 | 54 | 59 | 59 |
| muse-glimmer-30b | resid_post.layer38 | 68 | 43 | 64 | 64 |
| muse-glimmer-30b | resid_post.layer38 | 68 | 54 | 64 | 64 |
| muse-glimmer-30b | resid_post.layer51 | 59 | 43 | 59 | 59 |
| muse-glimmer-30b | resid_post.layer51 | 59 | 54 | 59 | 59 |
| muse-glimmer-30b | resid_post.layer51 | 68 | 43 | 64 | 64 |
| muse-glimmer-30b | resid_post.layer51 | 68 | 54 | 64 | 64 |
| qwen3.6-35b-a3b | resid_post.layer9 | 46 | 34 | 45 | 45 |
| qwen3.6-35b-a3b | resid_post.layer9 | 46 | 42 | 45 | 45 |
| qwen3.6-35b-a3b | resid_post.layer9 | 52 | 34 | 50 | 50 |
| qwen3.6-35b-a3b | resid_post.layer9 | 52 | 42 | 50 | 50 |
| qwen3.6-35b-a3b | resid_post.layer19 | 46 | 34 | 45 | 45 |
| qwen3.6-35b-a3b | resid_post.layer19 | 46 | 42 | 45 | 45 |
| qwen3.6-35b-a3b | resid_post.layer19 | 52 | 34 | 50 | 50 |
| qwen3.6-35b-a3b | resid_post.layer19 | 52 | 42 | 50 | 50 |
| qwen3.6-35b-a3b | resid_post.layer29 | 46 | 34 | 45 | 45 |
| qwen3.6-35b-a3b | resid_post.layer29 | 46 | 42 | 45 | 45 |
| qwen3.6-35b-a3b | resid_post.layer29 | 52 | 34 | 50 | 50 |
| qwen3.6-35b-a3b | resid_post.layer29 | 52 | 42 | 50 | 50 |
| qwen3.6-35b-a3b | resid_post.layer39 | 46 | 34 | 45 | 45 |
| qwen3.6-35b-a3b | resid_post.layer39 | 46 | 42 | 45 | 45 |
| qwen3.6-35b-a3b | resid_post.layer39 | 52 | 34 | 50 | 50 |
| qwen3.6-35b-a3b | resid_post.layer39 | 52 | 42 | 50 | 50 |
| llama-3.3-70b-instruct | resid_post.layer19 | 35 | 26 | 36 | 36 |
| llama-3.3-70b-instruct | resid_post.layer19 | 35 | 32 | 36 | 36 |
| llama-3.3-70b-instruct | resid_post.layer19 | 40 | 26 | 40 | 40 |
| llama-3.3-70b-instruct | resid_post.layer19 | 40 | 32 | 40 | 40 |
| llama-3.3-70b-instruct | resid_post.layer39 | 35 | 26 | 36 | 36 |
| llama-3.3-70b-instruct | resid_post.layer39 | 35 | 32 | 36 | 36 |
| llama-3.3-70b-instruct | resid_post.layer39 | 40 | 26 | 40 | 40 |
| llama-3.3-70b-instruct | resid_post.layer39 | 40 | 32 | 40 | 40 |
| llama-3.3-70b-instruct | resid_post.layer59 | 35 | 26 | 36 | 36 |
| llama-3.3-70b-instruct | resid_post.layer59 | 35 | 32 | 36 | 36 |
| llama-3.3-70b-instruct | resid_post.layer59 | 40 | 26 | 40 | 40 |
| llama-3.3-70b-instruct | resid_post.layer59 | 40 | 32 | 40 | 40 |
| llama-3.3-70b-instruct | resid_post.layer79 | 35 | 26 | 36 | 36 |
| llama-3.3-70b-instruct | resid_post.layer79 | 35 | 32 | 36 | 36 |
| llama-3.3-70b-instruct | resid_post.layer79 | 40 | 26 | 40 | 40 |
| llama-3.3-70b-instruct | resid_post.layer79 | 40 | 32 | 40 | 40 |

## E1. Consolidation layer by task (full transplant at every layer, >= 80% transfer)

| model | layers | counting (>=50% / >=80%) | copy | retrieval | copy first-token exact | retrieval first-token exact |
|---|---|---|---|---|---|---|
| gpt-oss-20b | 24 | 19 / 19 | 21 / 21 | 19 / 21 | 1.0 | 1.0 |
| gpt-oss-120b | 36 | 16 / 20 | 27 / 27 | 21 / 23 | 1.0 | 1.0 |
| gemma-4-26b-a4b-it | 30 | 27 / 28 | 25 / 25 | 25 / 26 | 1.0 | 1.0 |
| muse-glimmer-30b | 52 | 49 / 49 | 43 / 43 | 39 / 39 | 1.0 | 1.0 |
| qwen3.6-35b-a3b | 40 | 33 / 35 | 36 / 36 | 38 / 38 | 1.0 | 1.0 |
| llama-3.3-70b-instruct | 80 | 68 / 68 | 67 / 68 | 61 / 65 | 1.0 | 1.0 |

## E1. U transplant, complement and ablation by task (first-token transfer, informative donors)

| model | site | task | full | U | U comp. | U ablation survives | L | F | R8 | R16 | A8 | A16 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| gpt-oss-20b | resid_post.layer17 | counting | 0.067 | 0.0 | 0.067 | 20/20 | 20/20 | 20/20 | 40/40 | 40/40 | 20/20 | 20/20 |
| gpt-oss-20b | resid_post.layer23 | counting | 1.0 | 1.0 | 0.0 | 0/20 | 20/20 | 20/20 | 40/40 | 33/40 | 20/20 | 20/20 |
| gpt-oss-20b | resid_post.layer5 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-20b | resid_post.layer11 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-20b | resid_post.layer17 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-20b | resid_post.layer23 | copy | 1.0 | 1.0 | 0.0 | 1/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-20b | resid_post.layer5 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-20b | resid_post.layer11 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-20b | resid_post.layer17 | retrieval | 0.067 | 0.0 | 0.067 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-20b | resid_post.layer23 | retrieval | 1.0 | 1.0 | 0.0 | 1/20 | 20/20 | 20/20 | 20/20 | 19/20 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer26 | counting | 1.0 | 0.0 | 0.5 | 18/20 | 18/20 | 20/20 | 34/40 | 29/40 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer35 | counting | 1.0 | 1.0 | 0.0 | 4/20 | 20/20 | 20/20 | 39/40 | 31/40 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer8 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer17 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer26 | copy | 0.625 | 0.0 | 0.062 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer35 | copy | 1.0 | 1.0 | 0.0 | 6/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer8 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer17 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer26 | retrieval | 1.0 | 0.0 | 0.625 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gpt-oss-120b | resid_post.layer35 | retrieval | 1.0 | 1.0 | 0.0 | 3/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer21 | counting | 0.059 | 0.0 | 0.0 | 17/20 | 20/20 | 20/20 | 40/40 | 40/40 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer29 | counting | 1.0 | 0.0 | 0.0 | 0/20 | 20/20 | 20/20 | 40/40 | 40/40 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer7 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer14 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer21 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer29 | copy | 1.0 | 0.0 | 0.0 | 0/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer7 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer14 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer21 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| gemma-4-26b-a4b-it | resid_post.layer29 | retrieval | 1.0 | 0.0 | 0.0 | 0/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer38 | counting | 0.059 | 0.0 | 0.059 | 20/20 | 20/20 | 20/20 | 40/40 | 40/40 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer51 | counting | 1.0 | 1.0 | 0.0 | 0/20 | 20/20 | 20/20 | 40/40 | 40/40 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer12 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer25 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer38 | copy | 0.118 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer51 | copy | 1.0 | 1.0 | 0.0 | 0/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer12 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer25 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer38 | retrieval | 0.294 | 0.0 | 0.235 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| muse-glimmer-30b | resid_post.layer51 | retrieval | 1.0 | 1.0 | 0.0 | 0/20 | 20/20 | 20/20 | 20/20 | 19/20 | 20/20 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer39 | counting | 1.0 | 1.0 | 0.0 | 6/20 | 20/20 | 20/20 | 40/40 | 40/40 | 20/20 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer9 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer19 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer29 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer39 | copy | 1.0 | 1.0 | 0.0 | 6/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer9 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer19 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer29 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| qwen3.6-35b-a3b | resid_post.layer39 | retrieval | 1.0 | 1.0 | 0.0 | 6/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer59 | counting | 0.286 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 40/40 | 40/40 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer79 | counting | 1.0 | 1.0 | 0.0 | 6/20 | 20/20 | 20/20 | 39/40 | 38/40 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer19 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer39 | copy | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer59 | copy | 0.214 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer79 | copy | 1.0 | 1.0 | 0.0 | 1/20 | 20/20 | 20/20 | 20/20 | 19/20 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer19 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer39 | retrieval | 0.0 | 0.0 | 0.0 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer59 | retrieval | 0.357 | 0.0 | 0.071 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |
| llama-3.3-70b-instruct | resid_post.layer79 | retrieval | 1.0 | 1.0 | 0.0 | 5/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 | 20/20 |

## E1. Interpolation switch by task (first alpha with >= 50% / >= 90% donor)

| model | counting | copy | retrieval |
|---|---|---|---|
| gpt-oss-20b | 0.6 / 0.6 | 0.5 / 0.5 | 0.5 / 0.6 |
| gpt-oss-120b | 0.6 / 0.6 | 0.5 / 0.6 | 0.6 / 0.6 |
| gemma-4-26b-a4b-it | 0.5 / 0.6 | 0.5 / 0.5 | 0.5 / 0.6 |
| muse-glimmer-30b | 0.6 / 0.6 | 0.5 / 0.6 | 0.6 / 0.7 |
| qwen3.6-35b-a3b | 0.6 / 0.7 | 0.6 / 0.6 | 0.6 / 0.6 |
| llama-3.3-70b-instruct | 0.5 / 0.6 | 0.5 / 0.5 | 0.5 / 0.5 |

## E2. Logit-level interpolation at the last site

| model | pairs (with intermediate tokens) | intermediate leads argmax | of which the leader is an endpoint neighbour (within 2) / farther | intermediate logit exceeds both endpoints | median intermediate mass at alpha 0.5 | of which within 2 of an endpoint / farther (median; max farther) | same at the endpoints | median switch alpha |
|---|---|---|---|---|---|---|---|---|
| gpt-oss-20b | 15 (15) | 5 | 5 / 0 | 3 | 0.3325 | 0.2738 / 0.0391 (max 0.1656) | 0.0771 | 0.55 |
| gpt-oss-120b | 16 (16) | 2 | 1 / 1 | 2 | 0.327 | 0.1949 / 0.103 (max 0.3932) | 0.0993 | 0.55 |
| gemma-4-26b-a4b-it | 17 (12) | 0 | 0 / 0 | 0 | 0.0 | 0.0 / 0.0 (max 0.0) | 0.0 | 0.5 |
| muse-glimmer-30b | 17 (17) | 0 | 0 / 0 | 0 | 0.0777 | 0.0434 / 0.0243 (max 0.0732) | 0.0139 | 0.55 |
| qwen3.6-35b-a3b | 16 (5) | 0 | 0 / 0 | 0 | 0.0064 | 0.0 / 0.0 (max 0.0005) | 0.0 | 0.55 |
| llama-3.3-70b-instruct | 14 (14) | 0 | 0 / 0 | 0 | 0.0001 | 0.0 / 0.0 (max 0.0006) | 0.0 | 0.5 |

## E3. Exact-match accuracy of the rounded ridge readout (count-held-out folds) against the model

| model | site | in-regime probe exact / +-1 | model exact / +-1 (scan) | beyond-CC probe exact / +-1 | model exact / +-1 | mixed grid: in-grid CV exact / +-1 | homogeneous readout exact / +-1 | model exact / +-1 |
|---|---|---|---|---|---|---|---|---|
| gpt-oss-20b | resid_post.layer5 | 0.832 / 0.965 | 0.639 / 0.944 | 0.069 / 0.292 | 0.16 / 0.556 | 0.286 / 0.833 | 0.0 / 0.071 | 0.2619 / 0.405 |
| gpt-oss-20b | resid_post.layer11 | 0.776 / 0.97 | 0.639 / 0.944 | 0.09 / 0.215 | 0.16 / 0.556 | 0.071 / 0.429 | 0.0 / 0.048 | 0.2619 / 0.405 |
| gpt-oss-20b | resid_post.layer17 | 0.771 / 0.955 | 0.639 / 0.944 | 0.035 / 0.215 | 0.16 / 0.556 | 0.095 / 0.286 | 0.0 / 0.048 | 0.2619 / 0.405 |
| gpt-oss-20b | resid_post.layer23 | 0.566 / 0.875 | 0.639 / 0.944 | 0.014 / 0.139 | 0.16 / 0.556 | 0.048 / 0.31 | 0.048 / 0.095 | 0.2619 / 0.405 |
| gpt-oss-120b | resid_post.layer8 | 0.694 / 0.977 | 0.311 / 0.833 | 0.021 / 0.13 | 0.094 / 0.333 | 0.19 / 0.619 | 0.048 / 0.048 | 0.0952 / 0.31 |
| gpt-oss-120b | resid_post.layer17 | 0.586 / 0.921 | 0.311 / 0.833 | 0.036 / 0.141 | 0.094 / 0.333 | 0.095 / 0.286 | 0.0 / 0.0 | 0.0952 / 0.31 |
| gpt-oss-120b | resid_post.layer26 | 0.624 / 0.939 | 0.311 / 0.833 | 0.042 / 0.146 | 0.094 / 0.333 | 0.071 / 0.19 | 0.0 / 0.024 | 0.0952 / 0.31 |
| gpt-oss-120b | resid_post.layer35 | 0.51 / 0.938 | 0.311 / 0.833 | 0.057 / 0.177 | 0.094 / 0.333 | 0.071 / 0.19 | 0.048 / 0.095 | 0.0952 / 0.31 |
| gemma-4-26b-a4b-it | resid_post.layer7 | 0.768 / 0.995 | 0.794 / 1.0 | 0.03 / 0.201 | 0.148 / 0.263 | 0.143 / 0.262 | 0.0 / 0.024 | 0.2857 / 0.5 |
| gemma-4-26b-a4b-it | resid_post.layer14 | 0.725 / 0.979 | 0.794 / 1.0 | 0.013 / 0.053 | 0.148 / 0.263 | 0.071 / 0.238 | 0.0 / 0.0 | 0.2857 / 0.5 |
| gemma-4-26b-a4b-it | resid_post.layer21 | 0.628 / 0.969 | 0.794 / 1.0 | 0.036 / 0.115 | 0.148 / 0.263 | 0.214 / 0.429 | 0.0 / 0.024 | 0.2857 / 0.5 |
| gemma-4-26b-a4b-it | resid_post.layer29 | 0.314 / 0.712 | 0.794 / 1.0 | 0.003 / 0.013 | 0.148 / 0.263 | 0.024 / 0.167 | 0.071 / 0.143 | 0.2857 / 0.5 |
| muse-glimmer-30b | resid_post.layer12 | 0.814 / 0.978 | 0.77 / 1.0 | 0.0 / 0.089 | 0.143 / 0.429 | 0.262 / 0.69 | 0.024 / 0.095 | 0.0952 / 0.143 |
| muse-glimmer-30b | resid_post.layer25 | 0.774 / 0.975 | 0.77 / 1.0 | 0.049 / 0.125 | 0.143 / 0.429 | 0.095 / 0.262 | 0.0 / 0.024 | 0.0952 / 0.143 |
| muse-glimmer-30b | resid_post.layer38 | 0.634 / 0.933 | 0.77 / 1.0 | 0.022 / 0.062 | 0.143 / 0.429 | 0.048 / 0.214 | 0.0 / 0.071 | 0.0952 / 0.143 |
| muse-glimmer-30b | resid_post.layer51 | 0.402 / 0.854 | 0.77 / 1.0 | 0.009 / 0.049 | 0.143 / 0.429 | 0.095 / 0.238 | 0.0 / 0.048 | 0.0952 / 0.143 |
| qwen3.6-35b-a3b | resid_post.layer9 | 0.674 / 0.973 | 0.841 / 1.0 | 0.025 / 0.256 | 0.169 / 0.8 | 0.143 / 0.333 | 0.0 / 0.071 | 0.2857 / 0.619 |
| qwen3.6-35b-a3b | resid_post.layer19 | 0.734 / 0.973 | 0.841 / 1.0 | 0.075 / 0.275 | 0.169 / 0.8 | 0.143 / 0.357 | 0.024 / 0.024 | 0.2857 / 0.619 |
| qwen3.6-35b-a3b | resid_post.layer29 | 0.768 / 0.973 | 0.841 / 1.0 | 0.019 / 0.188 | 0.169 / 0.8 | 0.167 / 0.429 | 0.0 / 0.024 | 0.2857 / 0.619 |
| qwen3.6-35b-a3b | resid_post.layer39 | 0.427 / 0.844 | 0.841 / 1.0 | 0.025 / 0.113 | 0.169 / 0.8 | 0.262 / 0.571 | 0.167 / 0.357 | 0.2857 / 0.619 |
| llama-3.3-70b-instruct | resid_post.layer19 | 0.957 / 1.0 | 0.766 / 1.0 | 0.062 / 0.266 | 0.234 / 0.875 | 0.286 / 0.857 | 0.024 / 0.048 | 0.4762 / 0.738 |
| llama-3.3-70b-instruct | resid_post.layer39 | 0.75 / 0.91 | 0.766 / 1.0 | 0.102 / 0.281 | 0.234 / 0.875 | 0.238 / 0.452 | 0.071 / 0.119 | 0.4762 / 0.738 |
| llama-3.3-70b-instruct | resid_post.layer59 | 0.705 / 0.9 | 0.766 / 1.0 | 0.109 / 0.312 | 0.234 / 0.875 | 0.167 / 0.429 | 0.024 / 0.238 | 0.4762 / 0.738 |
| llama-3.3-70b-instruct | resid_post.layer79 | 0.482 / 0.785 | 0.766 / 1.0 | 0.008 / 0.102 | 0.234 / 0.875 | 0.238 / 0.619 | 0.095 / 0.19 | 0.4762 / 0.738 |
