# Tailored grid-ladder data

This directory is a derivative of the lossless raw archive named in `manifest.json`. It excludes Claude Fable 5 under the documented content-filter protocol exclusion, merges the Gemini 3.7 pilot with the original/lower/upper cohort records, enforces an 8,192-token per-request output cap, and truncates each logical scan at its tenth consecutive budget-exhausted scan response. The tenth row is retained with `tailoring.termination_record=true`; later rows remain available only in the archive and raw `results/` roots.

`scan_summary.csv` records completion and the worst-case remaining probe count. Creating this derivative makes no provider calls.
