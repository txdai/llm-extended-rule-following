# Excluded measurements

## Not a single model

    x-ai/grok-4.20-multi-agent

A multi-agent orchestration over grok-4.20 rather than one model. The assay
measures a model counting; what an orchestration does is a property of the
orchestration, so the row does not belong beside single-model measurements
whatever it scored. Excluded on what the endpoint is, not on how it scored --
its fitted transition was 60 with a 95% interval of [13, 90], too wide to
report either way.

## Serving-path failures

Three models were removed from the dataset because their records measure a
serving path, not a model. Each returned an unparseable response to every probe
(10 errors, 0 correct), so each would enter the table as CC=0 -- a value that
reads as "cannot count to one" when in fact no request ever reached a model.

    qwen/qwen-2.5-coder-32b-instruct           HTTP 500 from its sole provider
    mistralai/mistral-small-3.1-24b-instruct   HTTP 500 from its sole provider
    meta-llama/llama-guard-4-12b               a safety classifier, not a chat model

The first two return 500 only when the system prompt constrains output to a bare
integer, reproducibly (4/4), and answer normally without that constraint. They
are described in Appendix C.2. The raw records are kept here as the evidence for
that claim; they are outside `models/` and `trials/` so `build_dataset.py` does
not pick them up.
